{-
Copyright (C) 2004-2011 John Goerzen <jgoerzen@complete.org>

All rights reserved.

For license and copyright information, see the file LICENSE
-}


module Main where 

import Test.HUnit
import Tests

main = runTestTT tests

