{-
Copyright (C) 2004-2011 John Goerzen <jgoerzen@complete.org>

All rights reserved.

For license and copyright information, see the file LICENSE
-}


module IOtest() where
import Test.HUnit
import System.IO
import Test.HUnit.Tools






