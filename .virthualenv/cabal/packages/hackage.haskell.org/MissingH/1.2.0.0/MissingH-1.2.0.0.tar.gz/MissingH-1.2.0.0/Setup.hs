#!/usr/bin/env runhugs

import Distribution.Simple

main = defaultMain
