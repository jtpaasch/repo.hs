void myregfree(void *);

